# Match Advisor — prototype

Open this folder in Android Studio (JDK 17), let Gradle sync, then Run or Build > Build APK(s).

Version 0.1: import screenshot via Android document picker, recognize a 7×7 board calibrated to the supplied 709×1536 screenshot, tap a tile to cycle its recognized type, and show the three best swaps with an arrow for the top one. No auto-play, no screen recording, no floating overlay yet.

Tile symbols: R red, B blue, Y yellow, O orange, P purple, G green, ? unknown.

The score is a heuristic, NOT the game's exact score. The program cannot predict random falling tiles or booster effects. 4+ matches receive a large priority bonus. If the game's extra-turn rules change, adapt Engine.kt. Layout and recognition require further testing on device.

No APK is bundled: build with Android Studio. This project has not been compiled in this environment.
