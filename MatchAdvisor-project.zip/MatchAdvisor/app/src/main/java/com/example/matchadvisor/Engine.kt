package com.example.matchadvisor

/** Coordinates are zero-based: row, column. Unknown tiles are '?'. */
data class Move(val r1:Int,val c1:Int,val r2:Int,val c2:Int,val cleared:Int,val longest:Int,val groups:Int,val score:Int)
object Engine {
    private fun matches(b:Array<CharArray>): Pair<Set<Pair<Int,Int>>,Pair<Int,Int>> {
        val cells=mutableSetOf<Pair<Int,Int>>(); var longest=0; var groups=0
        for(r in 0..6) { var c=0; while(c<7) { var end=c+1; while(end<7 && b[r][c]!='?' && b[r][end]==b[r][c]) end++
            if(end-c>=3) { groups++; longest=maxOf(longest,end-c); for(x in c until end) cells.add(r to x) }; c=end } }
        for(c in 0..6) { var r=0; while(r<7) { var end=r+1; while(end<7 && b[r][c]!='?' && b[end][c]==b[r][c]) end++
            if(end-r>=3) { groups++; longest=maxOf(longest,end-r); for(x in r until end) cells.add(x to c) }; r=end } }
        return cells to (longest to groups)
    }
    fun find(b:Array<CharArray>):List<Move> {
        require(b.size==7 && b.all { it.size==7 })
        val result=mutableListOf<Move>()
        for(r in 0..6) for(c in 0..6) for((dr,dc) in listOf(0 to 1,1 to 0)) {
            val rr=r+dr; val cc=c+dc; if(rr>6 || cc>6 || b[r][c]=='?' || b[rr][cc]=='?' || b[r][c]==b[rr][cc]) continue
            val copy=Array(7){b[it].clone()}; val temp=copy[r][c]; copy[r][c]=copy[rr][cc]; copy[rr][cc]=temp
            val (tiles,details)=matches(copy); if(tiles.isEmpty()) continue
            // Heuristic, NOT actual Match Masters scoring. Prefer 4+ for extra-turn opportunities.
            val (longest,groups)=details
            val score=tiles.size*10 + (if(longest>=4) 1000 else 0) + (if(longest>=5) 300 else 0) + (groups-1)*35
            result.add(Move(r,c,rr,cc,tiles.size,longest,groups,score))
        }
        return result.sortedWith(compareByDescending<Move>{it.score}.thenByDescending{it.cleared})
    }
}
