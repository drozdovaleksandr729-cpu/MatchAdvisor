package com.example.matchadvisor

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.view.*
import android.widget.*
import java.io.InputStream
import kotlin.math.*

class MainActivity:Activity() {
    private lateinit var preview:BoardView
    private lateinit var status:TextView
    private var bitmap:Bitmap?=null
    private var board=Array(7){CharArray(7){'?'}}
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
        val layout=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(12,12,12,12) }
        val choose=Button(this).apply { text="Выбрать скриншот"; setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="image/*"; addCategory(Intent.CATEGORY_OPENABLE) },1) } }
        val analyze=Button(this).apply { text="Найти лучший ход"; setOnClickListener { analyze() } }
        status=TextView(this).apply { text="Загрузите скриншот с полем 7×7. Нажмите на клетку, чтобы исправить распознанный цвет."; textSize=16f }
        preview=BoardView(); layout.addView(choose);layout.addView(analyze);layout.addView(status);layout.addView(preview,LinearLayout.LayoutParams(-1,0,1f)); setContentView(layout)
    }
    @Deprecated("Legacy result API for minimal project") override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==1 && resultCode==RESULT_OK) { val uri:Uri=data?.data?:return
            bitmap=contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            bitmap?.let { board=Recognizer.read(it); preview.move=null; preview.invalidate(); status.text="Поле распознано. Проверьте цвета; касание клетки переключает тип фишки. Затем нажмите «Найти лучший ход»." }
        }
    }
    private fun analyze() { if(bitmap==null) { status.text="Сначала выберите скриншот";return }
        val moves=Engine.find(board); preview.move=moves.firstOrNull();preview.invalidate()
        status.text=if(moves.isEmpty()) "Комбинаций не найдено. Проверьте распознавание клеток." else moves.take(3).mapIndexed { i,m -> "${i+1}. (${m.r1+1},${m.c1+1}) → (${m.r2+1},${m.c2+1}); фишек: ${m.cleared}; максимум в линии: ${m.longest}${if(m.longest>=4) " ★ 4+" else ""}" }.joinToString("\n")+"\nОценка эвристическая; новые фишки неизвестны."
    }
    inner class BoardView:View(this) {
        var move:Move?=null
        private val paint=Paint(3)
        override fun onDraw(canvas:Canvas) { super.onDraw(canvas);val bmp=bitmap?:return
            val scale=min(width.toFloat()/bmp.width,height.toFloat()/bmp.height);val ox=(width-bmp.width*scale)/2;val oy=(height-bmp.height*scale)/2
            canvas.save();canvas.translate(ox,oy);canvas.scale(scale,scale);canvas.drawBitmap(bmp,0f,0f,null)
            val rect=Recognizer.bounds(bmp);val cw=rect.width()/7f;val ch=rect.height()/7f
            paint.style=Paint.Style.STROKE;paint.strokeWidth=3f/scale;paint.color=Color.WHITE
            for(i in 0..7) { canvas.drawLine(rect.left+i*cw,rect.top.toFloat(),rect.left+i*cw,rect.bottom.toFloat(),paint);canvas.drawLine(rect.left.toFloat(),rect.top+i*ch,rect.right.toFloat(),rect.top+i*ch,paint) }
            move?.let { m -> val x1=rect.left+(m.c1+.5f)*cw;val y1=rect.top+(m.r1+.5f)*ch;val x2=rect.left+(m.c2+.5f)*cw;val y2=rect.top+(m.r2+.5f)*ch
                paint.color=Color.GREEN;paint.strokeWidth=12f/scale;canvas.drawLine(x1,y1,x2,y2,paint);paint.style=Paint.Style.FILL;canvas.drawCircle(x2,y2,12f/scale,paint);paint.style=Paint.Style.STROKE }
            canvas.restore()
        }
        override fun onTouchEvent(e:android.view.MotionEvent):Boolean { if(e.action!=MotionEvent.ACTION_UP)return true;val bmp=bitmap?:return true
            val scale=min(width.toFloat()/bmp.width,height.toFloat()/bmp.height);val ox=(width-bmp.width*scale)/2;val oy=(height-bmp.height*scale)/2;val x=(e.x-ox)/scale;val y=(e.y-oy)/scale;val rect=Recognizer.bounds(bmp)
            if(x>=rect.left && x<rect.right && y>=rect.top && y<rect.bottom) { val c=((x-rect.left)*7/rect.width()).toInt().coerceIn(0,6);val r=((y-rect.top)*7/rect.height()).toInt().coerceIn(0,6);val types="RBYOPG?";board[r][c]=types[(types.indexOf(board[r][c])+1).coerceAtLeast(0)%types.length];move=null;status.text="Клетка (${r+1},${c+1}): ${board[r][c]} (R красная, B синяя, Y жёлтая, O оранжевая, P фиолетовая, G зелёная, ? неизвестно)";invalidate() };return true
        }
    }
}
object Recognizer {
    // Calibrated to the supplied 709 × 1536 screenshot. Other layouts need calibration.
    fun bounds(b:Bitmap)=Rect((13f/709*b.width).roundToInt(),(750f/1536*b.height).roundToInt(),(696f/709*b.width).roundToInt(),(1434f/1536*b.height).roundToInt())
    fun read(b:Bitmap):Array<CharArray> { val rect=bounds(b);val result=Array(7){CharArray(7){'?'}}
        for(r in 0..6)for(c in 0..6) { val x=rect.left+(c+.5)*rect.width()/7;val y=rect.top+(r+.5)*rect.height()/7
            // Sample multiple near-center pixels and vote, avoiding black outlines and white highlights.
            val votes=mutableMapOf<Char,Int>();for(dy in -2..2)for(dx in -2..2) {val px=(x+dx*rect.width()/140.0).roundToInt().coerceIn(0,b.width-1);val py=(y+dy*rect.height()/140.0).roundToInt().coerceIn(0,b.height-1);val hsv=FloatArray(3);Color.colorToHSV(b.getPixel(px,py),hsv);val h=hsv[0];val s=hsv[1];val v=hsv[2]
                val t=when {s<.28f || v<.24f -> '?';h<15 || h>=345 -> 'R';h<46 -> 'O';h<75 -> 'Y';h<165 -> 'G';h<245 -> 'B';h<325 -> 'P';else -> 'R'};if(t!='?')votes[t]=(votes[t]?:0)+1 }
            result[r][c]=votes.maxByOrNull{it.value}?.key?:'?'
        };return result
    }
}
